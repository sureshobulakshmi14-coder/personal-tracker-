const API_URL = "http://localhost:5000/api/expenses";

const expenseForm = document.getElementById("expenseForm");
const expenseTable = document.getElementById("expenseTable");
const totalExpense = document.getElementById("totalExpense");

const searchInput = document.getElementById("search");
const filterCategory = document.getElementById("filterCategory");

let expenses = [];


// Fetch expenses
async function fetchExpenses() {
    try {
        const response = await fetch(API_URL);
        expenses = await response.json();

        displayExpenses();
    } catch (error) {
        console.error("Error:", error);
    }
}


// Display expenses
function displayExpenses() {

    const searchText = searchInput.value.toLowerCase();
    const category = filterCategory.value;

    const filteredExpenses = expenses.filter(expense => {

        const matchesSearch =
            expense.title.toLowerCase().includes(searchText);

        const matchesCategory =
            category === "All" ||
            expense.category === category;

        return matchesSearch && matchesCategory;
    });

    expenseTable.innerHTML = "";

    filteredExpenses.forEach(expense => {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${expense.title}</td>

            <td>₹${expense.amount}</td>

            <td>${expense.category}</td>

            <td>
                <button
                    class="edit-btn"
                    onclick="editExpense(${expense.id})"
                >
                    Edit
                </button>

                <button
                    class="delete-btn"
                    onclick="deleteExpense(${expense.id})"
                >
                    Delete
                </button>
            </td>
        `;

        expenseTable.appendChild(row);
    });

    calculateTotal();
}


// Calculate total
function calculateTotal() {

    const total = expenses.reduce(
        (sum, expense) => sum + Number(expense.amount),
        0
    );

    totalExpense.textContent = `₹${total}`;
}


// Add expense
expenseForm.addEventListener("submit", async (event) => {

    event.preventDefault();

    const title = document.getElementById("title").value;
    const amount = document.getElementById("amount").value;
    const category = document.getElementById("category").value;

    try {

        await fetch(API_URL, {
            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                title,
                amount,
                category
            })
        });

        expenseForm.reset();

        fetchExpenses();

    } catch (error) {
        console.error("Error:", error);
    }
});


// Delete expense
async function deleteExpense(id) {

    if (!confirm("Delete this expense?")) {
        return;
    }

    try {

        await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });

        fetchExpenses();

    } catch (error) {
        console.error("Error:", error);
    }
}


// Edit expense
async function editExpense(id) {

    const expense = expenses.find(item => item.id === id);

    if (!expense) {
        return;
    }

    const title = prompt("Enter expense name:", expense.title);
    const amount = prompt("Enter amount:", expense.amount);
    const category = prompt("Enter category:", expense.category);

    if (!title || !amount || !category) {
        return;
    }

    try {

        await fetch(`${API_URL}/${id}`, {
            method: "PUT",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                title,
                amount,
                category
            })
        });

        fetchExpenses();

    } catch (error) {
        console.error("Error:", error);
    }
}


// Search
searchInput.addEventListener("input", displayExpenses);


// Filter
filterCategory.addEventListener("change", displayExpenses);


// Initial load
fetchExpenses();
